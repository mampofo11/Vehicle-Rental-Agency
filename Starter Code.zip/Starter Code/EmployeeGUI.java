public class EmployeeGUI_Interface implements UserInterface {
	
	// No constructor needed, calls static methods of the SystemInterface.
	// Method start begins a command loop that repeatedly: (a) displays a menu of options, 
      // (b) gets the selected option from the user, and (c) executes the corresponding command.

	private boolean quit = false;
 	public void start(Scanner input) {

	int selection;

	// command loop
	while(!quit) {
		displayMenu();
		selection = getSelection(input):
		execute(selection, input);
	}
      }
	
     // ------- private methods

      private void execute(int selection, Scanner input)

             int veh_type;
	String vin, creditcard_num;  
 	String[] display_lines;
	RentalDetails rental_details;  
	Reservation_Details reserv_details;

	switch(selection) {

		// display rental rates
		case 1: veh_type = getVehicleType(input);
				switch(veh_type) {
				    case 1: display_lines = SystemInterface.getCarRates(); break;
				    case 2: display_lines = SystemInterface.getSUVRates(); break;
			      	    case 3: display_lines = SystemInterface.getMinivanRates(); break;
				}
				displayResults(display_lines);
				break;

		// display available vehicles
		case 2:	veh_type = getVehicleType(input);
				switch(veh_type) {
				    case 1: display_lines = SystemInterface.getAvailCars(); break;
				    case 2: display_lines = SystemInterface.getAvailSUVs(); break;
			      	    case 3: display_lines = SystemInterface.getAvailMinivans(); break;
				}
				displayResults(display_lines);
				break;
		// display estimated rental cost
		case 3:	rental_details = getRentalDetails(input);
				display_lines = SystemInterface.calcRentalCost(rental_details);
				displayResults(display_lines);
				break;
		 		
		// make a reservation
		case 4:	reserv_details = getReservationDetails(input);
				display_lines = SystemInterface.makeReservation(reserv_details);
				displayResults(display_lines);
				break;
		
		// cancel a reservation
		case 5:	vin = getVIN(user_input);
				display_lines = SystemInterface.cancelReservation(creditcard_num, vin);
				displayResults(display_lines);
				break;

		// process returned vehicle
		case 6:	creditcard_num = getCreditCardNum(user_input);
				vin = getVIN(input);
				display_lines = SystemInterface.processReturnedVehicle(vin, 
 								       num_day_used,num_miles_driven);
				displayResults(display_lines);
				break;

		// quit program
		case 7: quit = true;
	}

	private void displayMenu() {   }
 	// displays the user options

	private int getSelection(Scanner input) {   }
 	// prompts user for selection from menu (continues to prompt if selection < 1 or selection > 8)

	private String getVIN(Scanner input)
	// prompts user to enter VIN for a given vehicle (does not do any error checking on the input) {    }

	private int getVehicleType(Scanner input)
	// prompts user to enter 1, 2, or 3, and returns (continues to prompt user if invalid input given) {    }

	private RentalDetails getRentalDetails(Scanner input)
	// prompts user to enter required information for an estimated rental cost (vehicle type, estimated  
 	// number of miles expected to be driven, expected rental period and optional insuranc, returning the
 	// result packaged as a RentalDetails object (to pass in method calls to the SystemInterface) {   }

	private ReservationDetails getReservationDetails(Scanner input)
	// prompts user to enter required information for making a reservation (VIN of vehicle to reserve, 
 	// credit card num, rental period, and optional insurance), returning the result packaged as a 
 	// ReservationDetails object (to pass in method calls to the SystemInterface)  {    }

	private void displayResults(String[] lines)
	// displays the array of strings passed, one string per screen line {    }
}

