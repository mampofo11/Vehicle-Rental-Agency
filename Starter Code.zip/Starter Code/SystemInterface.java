public class SystemInterface {

	private static CurrentRates agency_rates;
	private static Vehicles agency_vehicles;
	private static Transactions transactions_history;

	// used to init static variables (in place of a constructor)
	public static void initSystem(CurrentRates r, Vehicles v, Transactions t) {
		agency_rates = r;
		agency_vehicles = v;
		transactions_history = t;
	}
	
// Note that methods makeReservation, cancelReservation and updateXXXRates return an
// acknowledgement of successful completion of the requested action (e.g. “Vehicle ABC123
// successfully reserved”). Method processReturnedVehicle returns the final cost for the returned 
// vehicle (e.g., “Total charge for VIN ABC123 for 3 days, 233 miles @  0.15/mile and daily
// insurance @ 14.95/day = $xxx.xx.)
	// Current Rates Related Methods
	public static String[ ] getCarRates() { ... }
	public static String[ ] getSUVRates() { ... }
	public static String[ ] getMinivanRates() { ... }

	public static String[ ] updateCarRates(VehicleRates r) { ... }
	public static String[ ] updateSUVRates(VehicleRates r) { ... }
	public static String[ ] updateMinivanRates(VehicleRates r) { ... }

public static String[ ] calcRentalCost(RentalDetails details) { ... }
public static String[ ] processReturnedVehicle(String vin, int num_days_used, int num_miles_driven) { ... }

// Note that the rates to be used are retrieved from the VehicleRates object stored in the specific rented
// vehicle object, and the daily insurance option is retrieved from the Reservation object of the rented
// vehicle

	// Vehicle Related Methods
public static String[ ] getAvailCars() { ... }
public static String[ ] getAvailSUVs() { ... }
public static String[ ] getAvailMinivans() { ... }
public static String[ ] getAllVehicles() { ... }

public static String[ ] makeReservation(ReservationDetails details) { ... }
public static String[ ] cancelReservation(String vin) { ... }
public static String[ ] getReservation(String vin) { ... }
public static String[ ] getAllReservations() { ... }


// transactions-related methods
public static String[ ] addTransaction() { ... }  
	public static String[ ] getAllTransactions() { ... }  

}